﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int RegistrosInsertados;
            int registrosActualizados;
            int RegistrosEliminados;
            int numeroFilasSelect;

            DataSet dataSetSelectProductos = new DataSet();
            dataSetSelectProductos = ListaProductos();
            RegistrosInsertados = CantidadRegistrosInsertados();
            registrosActualizados = CantidadRegistrosActualizados();
            RegistrosEliminados = CantidadRegistrosEliminados();
            numeroFilasSelect = CantidadRegistrosSelectMiTabla();

        }

        /// <summary>
        /// Metodo que devuelve el numero de filas 
        /// </summary>
        /// <returns></returns>
        static int CantidadRegistrosSelectMiTabla()
        {

            int cantidadRegistrosSelect = 0;
            using (var connection = GetConnection())
            {

                string SelectMiTabla = "SELECT * FROM miTabla";

                try
                {
                    using (var command = new SqlCommand(SelectMiTabla, connection))
                    {
                        command.CommandType = System.Data.CommandType.Text;
                        connection.Open();
                        cantidadRegistrosSelect = Convert.ToInt32(command.ExecuteNonQuery());

                    }
                }
                catch (SqlException e)
                {
                    Console.WriteLine("Error al consultar los datos: " + e.Message.ToString());
                }
                finally
                {
                    connection.Close();
                }


            }

            return cantidadRegistrosSelect;
        }

        /// <summary>
        /// Metodo que devuelve la cantidad de registros eliminados
        /// </summary>
        /// <returns></returns>
        static int CantidadRegistrosEliminados()
        {

            int cantidadEliminados = 0;
            using (var connection = GetConnection())
            {

                string DeletetMiTabla = "DELETE FROM miTabla";

                try
                {
                    using (var command = new SqlCommand(DeletetMiTabla, connection))
                    {
                        command.CommandType = System.Data.CommandType.Text;
                        connection.Open();
                        cantidadEliminados = Convert.ToInt32(command.ExecuteNonQuery());

                    }
                }
                catch (SqlException e)
                {
                    Console.WriteLine("Error al eliminar los datos: " + e.Message.ToString());
                }
                finally
                {
                    connection.Close();
                }


            }

            return cantidadEliminados;
        }

        /// <summary>
        /// Metodo que devuelve la cantidad de registros actualizados
        /// </summary>
        /// <returns></returns>
        static int CantidadRegistrosActualizados()
        {

            int cantidadActualizados = 0;
            using (var connection = GetConnection())
            {

                string UpdatetMiTabla = "update miTabla set campo_uno = '' where campo_dos and campo_tres";

                try
                {
                    using (var command = new SqlCommand(UpdatetMiTabla, connection))
                    {
                        command.CommandType = System.Data.CommandType.Text;
                        connection.Open();
                        cantidadActualizados = Convert.ToInt32(command.ExecuteNonQuery());

                    }
                }
                catch (SqlException e)
                {
                    Console.WriteLine("Error al actualizar los datos: " + e.Message.ToString());
                }
                finally
                {
                    connection.Close();
                }


            }

            return cantidadActualizados;
        }

        /// <summary>
        /// Metodo que devuelve la cantidad de registros insertados
        /// </summary>
        /// <returns></returns>
        static int CantidadRegistrosInsertados()
        {

            int cantidadInserciones = 0;
            using (var connection = GetConnection())
            {

                string insertMiTabla = "insert into miTabla values('','','','')";

                try
                {
                    using (var command = new SqlCommand(insertMiTabla, connection))
                    {
                        command.CommandType = System.Data.CommandType.Text;
                        connection.Open();
                        cantidadInserciones = Convert.ToInt32(command.ExecuteNonQuery());
                        
                    }
                }
                catch (SqlException e)
                {
                    Console.WriteLine("Error al insertar los datos: " + e.Message.ToString());
                }
                finally
                {
                    connection.Close();
                }

                
            }

            return cantidadInserciones;
        }

        /// <summary>
        /// Metodo que devuelve la lista de productos
        /// </summary>
        /// <returns></returns>
        public static DataSet ListaProductos()
        {

            DataSet dataSet = new DataSet();

            try
            {
                using (var connection = GetConnection())
                {

                    string productos = "SELECT * FROM producto";
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(productos, connection);
                    dataAdapter.Fill(dataSet);

                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error al consultar la tabla productos: " + ex.Message.ToString());
            }
           

            return dataSet;

        }
        /// <summary>
        /// Metodo que se utiliza para invocar la conexion a la base de datos
        /// </summary>
        /// <returns></returns>
        private static SqlConnection GetConnection()
        {
            SqlConnection ConexionBd = new SqlConnection();

            try
            {
                ConexionBd = new SqlConnection(ConnectionString);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error en la conexion a la base de datos: " + ex.Message.ToString());
            }

            return ConexionBd;

        }

        /// <summary>
        /// Metodo que hace la conexion SQL Server (cadena configurada en el archivo web.config)
        /// </summary>
        public static string ConnectionString
        {
            get
            {
                return System.Configuration.ConfigurationManager.ConnectionStrings["ConexionSql"].ToString();
            }
        }
    }
}